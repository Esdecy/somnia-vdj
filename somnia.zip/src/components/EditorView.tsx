/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  ArrowLeft,
  Undo2,
  Redo2,
  Tv,
  Edit2,
  FileText,
  Palette,
  Layers,
  Sparkles,
  Scissors,
  Copy,
  Clipboard,
  Plus,
  Play,
  Volume2,
  Eye,
  Lock,
  Compass,
  Smile,
  Zap,
  MessageSquare,
  HelpCircle,
  Send,
  Loader2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Dream, TrackClip } from "../types";
import DreamPlayer from "./DreamPlayer";

interface EditorViewProps {
  dream: Dream;
  onNavigateBack: () => void;
  onSaveDream: (updatedDream: Dream) => void;
  onTriggerGeminiGenerate: (prompt: string, style: string) => Promise<string>;
}

export default function EditorView({
  dream,
  onNavigateBack,
  onSaveDream,
  onTriggerGeminiGenerate,
}: EditorViewProps) {
  const [activeDream, setActiveDream] = useState<Dream>(dream);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(dream.title);
  const [refinePrompt, setRefinePrompt] = useState(dream.visuals.refinePrompt);
  const [isRendering, setIsRendering] = useState(false);

  // Interpretation Panel state variables
  const [interpretation, setInterpretation] = useState<string>("");
  const [interpreting, setInterpreting] = useState(false);
  const [customQuestion, setCustomQuestion] = useState("");
  const [interpreterChat, setInterpreterChat] = useState<{ sender: "user" | "somnia"; text: string }[]>([]);
  const [selectedPresetSymbol, setSelectedPresetSymbol] = useState<string | null>(null);

  // States to implement simple undo/redo
  const [history, setHistory] = useState<Dream[]>([dream]);
  const [historyIdx, setHistoryIdx] = useState(0);

  const [showStudioGuide, setShowStudioGuide] = useState(false);
  const [currentGuideStep, setCurrentGuideStep] = useState(0);
  const [showSubconsciousGuide, setShowSubconsciousGuide] = useState(true);

  const guideSteps = [
    {
      title: "🎬 Welcome to the Somnia Creative Studio",
      text: "This studio converts your recalled dreams into cinematic video drafts. Here you can tweak individual scenes, add mental layer overlays, or consult the Subconscious Interpreter.",
    },
    {
      title: "⏱️ The Dream Timeline Scrubber",
      text: "At the bottom of the workspace is the timeline track. Each block represents 1 second of your dream video. Tap any block or scrub the playhead to fine-tune exact transition frames!",
    },
    {
      title: "🎨 Cinematic Art Styles & Prompts",
      text: "Under GLOBAL STYLE, you can change the artistic filter of the dream (e.g. Noir, Anime/Ghibli, or Cyberpunk) instantly. Use the 'Refine Visual Prompt' input directly above it to type in precise visual guidance of what actually occurs in the scene, then press 'RENDER' to re-cook the clip with AI core logic.",
    },
    {
      title: "🧭 Freeform Spatial Location & Mind Overlays",
      text: "Type in any freeform physical setting in the 'DREAM LAYERS' parameters, and assign emotion overlays (like Melancholy, Serenity or Awe) to color the atmospheric lighting.",
    },
    {
      title: "📖 AI Subconscious Interpreter Guide",
      text: "Select a custom symbol or key question in the right-side chat and the counselor will guide you through interpreting the dream's hidden psychology based on your active Life Milestone chapters.",
    }
  ];

  const pushToHistory = (newDream: Dream) => {
    const updatedHistory = history.slice(0, historyIdx + 1);
    updatedHistory.push(newDream);
    setHistory(updatedHistory);
    setHistoryIdx(updatedHistory.length - 1);
    setActiveDream(newDream);
    onSaveDream(newDream);
  };

  const handleUndo = () => {
    if (historyIdx > 0) {
      const idx = historyIdx - 1;
      setHistoryIdx(idx);
      setActiveDream(history[idx]);
    }
  };

  const handleRedo = () => {
    if (historyIdx < history.length - 1) {
      const idx = historyIdx + 1;
      setHistoryIdx(idx);
      setActiveDream(history[idx]);
    }
  };

  // Timeline scrubber slide trigger based on timeline click
  const handleTimelineScrub = (percent: number) => {
    const time = percent * activeDream.duration;
    setCurrentTime(Math.min(activeDream.duration, Math.max(0, time)));
  };

  const selectStyle = (styleName: string) => {
    const updated = {
      ...activeDream,
      visuals: {
        ...activeDream.visuals,
        style: styleName,
      },
    };
    pushToHistory(updated);
  };

  const saveTitle = () => {
    const updated = {
      ...activeDream,
      title: titleInput || activeDream.title,
    };
    setIsEditingTitle(false);
    pushToHistory(updated);
  };

  // Triggers prompt refinements back via Gemini!
  const handleApplyPrompt = () => {
    const updated = {
      ...activeDream,
      visuals: {
        ...activeDream.visuals,
        refinePrompt,
      },
    };
    pushToHistory(updated);
  };

  const handleRenderVisual = async () => {
    setIsRendering(true);
    try {
      // Call Gemini proxy on the server-side to generate a brand new image
      const image64 = await onTriggerGeminiGenerate(refinePrompt, activeDream.visuals.style);
      if (image64) {
        const updated = {
          ...activeDream,
          visuals: {
            ...activeDream.visuals,
            imageUrl: image64,
          },
        };
        pushToHistory(updated);
      }
    } catch (e) {
      console.error("Gemini Render error, falling back to dynamic styled layer", e);
    } finally {
      setIsRendering(false);
    }
  };

  // Add standard detail tags
  const injectDetailTag = (type: "emotion" | "location") => {
    if (type === "emotion") {
      const emos = ["Sublime", "Melancholy", "Awe", "Thrilling", "Uncanny"];
      const r = emos[Math.floor(Math.random() * emos.length)];
      const updated = {
        ...activeDream,
        details: {
          ...activeDream.details,
          emotion: r,
        },
      };
      pushToHistory(updated);
    } else {
      const locs = ["Quantum Fields", "Nebula Chamber", "Shattered Colosseum", "Memory Lake"];
      const l = locs[Math.floor(Math.random() * locs.length)];
      const updated = {
        ...activeDream,
        details: {
          ...activeDream.details,
          spatialContext: l,
        },
      };
      pushToHistory(updated);
    }
  };

  const handleRequestInterpretation = async (customQ?: string) => {
    setInterpreting(true);
    const questionText = customQ || customQuestion;
    
    if (questionText) {
      setInterpreterChat(prev => [...prev, { sender: "user", text: questionText }]);
      setCustomQuestion("");
    }

    try {
      const response = await fetch("/api/interpret-dream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: activeDream.text,
          question: questionText || undefined
        })
      });
      const data = await response.json();
      if (data.status === "success" || data.status === "fallback") {
        if (questionText) {
          setInterpreterChat(prev => [...prev, { sender: "somnia", text: data.interpretation }]);
        } else {
          setInterpretation(data.interpretation);
        }
      }
    } catch (err) {
      console.error(err);
      const errMsg = "Fell back. Compare your current life milestones and sleep bed environmental conditions to parse active REM triggers.";
      if (questionText) {
        setInterpreterChat(prev => [...prev, { sender: "somnia", text: errMsg }]);
      } else {
        setInterpretation(errMsg);
      }
    } finally {
      setInterpreting(false);
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col font-body-sm text-body-sm overflow-hidden select-none relative bg-background">
      {/* Top Header toolbar matching design specs */}
      <header className="bg-background/85 backdrop-blur-xl h-16 shrink-0 border-b border-white/10 shadow-[0_0_20px_rgba(202,194,225,0.08)] flex justify-between items-center px-4 relative z-30">
        <div className="flex items-center gap-3">
          <button
            onClick={onNavigateBack}
            className="text-primary hover:text-tertiary p-2 -ml-2 rounded-full hover:bg-white/5 transition-all text-left focus:outline-none cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="font-headline-lg-mobile text-lg text-primary tracking-widest hidden md:block select-none">
            Somnia
          </span>
        </div>

        {/* Dynamic Title Editor */}
        <div className="flex-1 flex justify-center items-center">
          <div className="flex items-center gap-2 glass-panel rounded-full px-4 py-1 border border-white/5 shadow-sm">
            <span className="text-on-surface-variant/75 text-xs">Editing:</span>
            {isEditingTitle ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  onBlur={saveTitle}
                  onKeyDown={(e) => e.key === "Enter" && saveTitle()}
                  className="bg-black/40 text-sm text-[#ecb2ff] font-semibold border-b border-secondary px-2 py-0.5 focus:outline-none w-36"
                  autoFocus
                />
              </div>
            ) : (
              <div className="flex items-center gap-1">
                <span className="font-title-md text-sm text-secondary font-semibold">
                  {activeDream.title}
                </span>
                <button
                  onClick={() => setIsEditingTitle(true)}
                  className="text-on-surface-variant/60 hover:text-white p-1 rounded transition-colors focus:outline-none cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Undo, Redo, Render CTA */}
        <div className="flex items-center gap-2 md:gap-3.5">
          <button
            onClick={() => {
              setShowStudioGuide(true);
              setCurrentGuideStep(0);
            }}
            className="p-1 px-2.5 md:p-2 text-[#00dbe9] hover:text-white bg-white/5 hover:bg-[#00dbe9]/10 border border-[#00dbe9]/30 rounded-full transition-all focus:outline-none cursor-pointer flex items-center gap-1 text-[10px] md:text-xs font-bold font-mono"
            title="Start Studio Walkthrough"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Guide Tour</span>
          </button>

          <button
            disabled={historyIdx === 0}
            onClick={handleUndo}
            className={`p-2 rounded-full hover:bg-white/5 transition-all focus:outline-none ${
              historyIdx === 0 ? "opacity-30 cursor-not-allowed" : "text-primary hover:text-tertiary cursor-pointer"
            }`}
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            disabled={historyIdx === history.length - 1}
            onClick={handleRedo}
            className={`p-2 rounded-full hover:bg-white/5 transition-all focus:outline-none ${
              historyIdx === history.length - 1
                ? "opacity-30 cursor-not-allowed"
                : "text-primary hover:text-tertiary cursor-pointer"
            }`}
          >
            <Redo2 className="w-4 h-4" />
          </button>

          <button
            onClick={handleRenderVisual}
            disabled={isRendering}
            className="bg-gradient-to-tr from-secondary-container to-tertiary text-on-primary px-4 py-2 rounded-full font-label-caps text-[10px] tracking-wider flex items-center gap-1.5 hover:opacity-90 active:scale-95 transition-all shadow-[0_0_15px_rgba(236,178,255,0.25)] ml-1.5 focus:outline-none cursor-pointer font-bold"
          >
            <Tv className="w-3.5 h-3.5" />
            RENDER
          </button>
        </div>
      </header>

      {/* Main Workspace Frame container */}
      <main className="flex-1 flex flex-col md:flex-row overflow-hidden relative z-10">
        {/* Left column: Player and styling refinement boxes */}
        <section className="flex-1 flex flex-col overflow-y-auto p-4 gap-4 bg-surface-container-lowest/40 scrollbar-thin">
          {/* Active play dream screen */}
          <DreamPlayer
            dream={activeDream}
            currentTime={currentTime}
            isPlaying={isPlaying}
            onTimeUpdate={setCurrentTime}
            onTogglePlay={() => setIsPlaying(!isPlaying)}
            isRendering={isRendering}
          />

          {/* Contextual control boxes row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Prompt refinement column panel */}
            <div className="glass-panel p-4 rounded-xl flex flex-col gap-2 border border-white/5 text-left">
              <div className="flex justify-between items-center text-on-surface-variant font-label-caps text-[10px] tracking-wider font-semibold">
                <span className="flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-secondary" />
                  REFINE VISUAL PROMPT
                </span>
                <span className="text-secondary/70 font-mono">Frame 12</span>
              </div>
              <textarea
                value={refinePrompt}
                onChange={(e) => setRefinePrompt(e.target.value)}
                className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 font-body-sm text-xs text-on-surface focus:border-tertiary/55 focus:ring-1 focus:ring-tertiary outline-none resize-none h-16 scrollbar-none"
                placeholder="Describe your adjustments..."
              />
              <button
                onClick={handleApplyPrompt}
                className="w-full py-1.5 bg-white/5 hover:bg-white/10 hover:text-white rounded-lg border border-white/5 font-label-caps text-[9px] tracking-wider text-secondary transition-colors cursor-pointer"
              >
                Apply to Clip
              </button>
            </div>

            {/* Visual Style Selector box */}
            <div className="glass-panel p-4 rounded-xl flex flex-col gap-2 border border-white/5 text-left">
              <span className="font-label-caps text-[10px] tracking-wider text-on-surface-variant flex items-center gap-1 font-semibold">
                <Palette className="w-3.5 h-3.5 text-tertiary" />
                GLOBAL STYLE
              </span>
              <div className="grid grid-cols-2 gap-1.5 flex-grow overflow-y-auto max-h-[140px] pr-1 scrollbar-none">
                {["Synthwave", "Ghibli", "Noir", "Hyper-real", "Oil Painting", "Cinematic", "Surrealism", "Cyberpunk"].map((sty) => {
                  const isSel = activeDream.visuals.style === sty;
                  return (
                    <button
                      key={sty}
                      onClick={() => selectStyle(sty)}
                      className={`py-1.5 rounded text-[10px] font-semibold tracking-wide border transition-all cursor-pointer ${
                        isSel
                          ? "bg-tertiary/15 border-tertiary text-tertiary shadow-[0_0_10px_rgba(0,219,233,0.15)]"
                          : "bg-black/20 border-white/5 text-on-surface-variant hover:text-white"
                      }`}
                    >
                      {sty}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dream Layer overlays */}
            <div className="glass-panel p-4 rounded-xl flex flex-col gap-2 border border-white/5 text-left transition-all">
              <div className="flex justify-between items-center pb-1 border-b border-white/5">
                <span className="font-label-caps text-[10px] tracking-wider text-on-surface-variant flex items-center gap-1 font-semibold">
                  <Layers className="w-3.5 h-3.5 text-primary" />
                  DREAM BIO-LAYERS
                </span>
              </div>
              
              <div className="flex flex-col gap-3 mt-1 flex-grow justify-center">
                <div className="space-y-2.5 animate-fadeIn">
                  <div className="flex flex-col">
                    <span className="text-[9px] font-mono text-tertiary tracking-wider font-extrabold uppercase block leading-none">
                      Spatial Realm
                    </span>
                    <span className="text-xs text-on-surface font-medium truncate mt-1 flex items-center gap-1.5">
                      <Compass className="w-3 h-3 text-tertiary shrink-0 animate-spin-slow" />
                      {activeDream.details.spatialContext || "Infinite Void"}
                    </span>
                  </div>

                  <div className="flex flex-col">
                    <span className="text-[9px] font-mono text-secondary tracking-wider font-extrabold uppercase block leading-none">
                      Atmospheric Emotion Accent
                    </span>
                    <span className="text-xs text-on-surface font-medium truncate mt-1 flex items-center gap-1.5">
                      <Smile className="w-3 h-3 text-secondary shrink-0" />
                      {activeDream.details.emotion || "Not specified"}
                    </span>
                  </div>

                  <div className="flex flex-col gap-1 border-t border-white/5 pt-1.5 space-y-1">
                    <div className="flex items-center justify-between text-[9px] font-mono text-on-surface-variant/80">
                      <span>Physical Bed:</span>
                      <span className="text-primary font-bold">{activeDream.sleepEnvironment || "Home Bed"}</span>
                    </div>
                    <div className="flex items-center justify-between text-[9px] font-mono text-on-surface-variant/80">
                      <span>Milestone epoch:</span>
                      <span className="text-[#ca9eff] font-bold truncate max-w-[120px]" title={activeDream.lifeEpoch}>
                        {activeDream.lifeEpoch || "Ordinary Life"}
                      </span>
                    </div>
                  </div>

                  <div className="pt-1.5 border-t border-white/5">
                    <button
                      onClick={onNavigateBack}
                      className="w-full py-1.5 text-[9px] font-bold text-center bg-secondary/10 hover:bg-secondary/20 text-secondary border border-secondary/20 rounded-md transition-all cursor-pointer uppercase tracking-wider flex items-center justify-center gap-1"
                    >
                      ✏️ Edit Journal Parameters
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* Right column sidebar: Somnia Subconscious Interpreter Guide */}
        {!showSubconsciousGuide ? (
          <aside className="w-full lg:w-12 border-t lg:border-t-0 lg:border-l border-white/10 bg-[#0f1122]/95 flex lg:flex-col items-center justify-between p-2.5 lg:py-4 shrink-0 transition-all duration-300">
            <button
              onClick={() => setShowSubconsciousGuide(true)}
              className="text-[#ca9eff] hover:text-white p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-all mx-auto cursor-pointer flex items-center lg:flex-col gap-2"
              title="Expand Interpreter Panel"
            >
              <MessageSquare className="w-5 h-5 shadow" />
              <span className="text-[9px] font-mono uppercase tracking-widest hidden lg:block select-none font-extrabold [writing-mode:vertical-lr] py-2">Consult Guide</span>
            </button>
          </aside>
        ) : (
          <aside className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-white/10 bg-[#0f1122]/95 flex flex-col h-full overflow-hidden shrink-0 transition-all duration-300 relative">
            {/* Header block with statistics & metadata */}
            <div className="p-4 border-b border-white/5 space-y-2 shrink-0 bg-black/15 text-left bg-gradient-to-tr from-[#ca9eff]/5 to-transparent flex justify-between items-start gap-2 animate-fadeIn">
              <div className="space-y-0.5 flex-1 min-w-0">
                <h3 className="text-xs font-bold font-label-caps tracking-widest text-[#ca9eff] flex items-center gap-1.5 animate-pulse">
                  <MessageSquare className="w-4 h-4 text-[#ca9eff] shrink-0" /> Somnia Subconscious Guide
                </h3>
                <p className="text-[10px] text-on-surface-variant/80">
                  Correlate patterns to interpret REM dream structures.
                </p>

                {/* Bedrock correlations badges */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {activeDream.lifeEpoch && (
                    <span className="text-[9px] font-mono bg-[#ca9eff]/10 border border-[#ca9eff]/20 text-[#ca9eff] px-2 py-0.5 rounded">
                      Milestone: {activeDream.lifeEpoch}
                    </span>
                  )}
                  {activeDream.sleepEnvironment && (
                    <span className="text-[9px] font-mono bg-[#00dbe9]/10 border border-[#00dbe9]/20 text-[#00dbe9] px-2 py-0.5 rounded">
                      Bed: {activeDream.sleepEnvironment}
                    </span>
                  )}
                </div>
              </div>

              <button
                onClick={() => setShowSubconsciousGuide(false)}
                className="p-1 px-2 text-[9px] text-[#ca9eff] hover:text-white bg-[#ca9eff]/10 hover:bg-[#ca9eff]/20 border border-[#ca9eff]/20 rounded-md transition-all cursor-pointer font-bold shrink-0 uppercase tracking-wide"
                title="Collapse Sidebar"
              >
                ✕ Hide
              </button>
            </div>

          <div className="flex-grow overflow-y-auto p-4 space-y-4 scrollbar-thin">
            {/* Main interpretation wrapper */}
            <div className="space-y-2.5">
              <span className="text-[10px] font-bold font-label-caps tracking-wider text-on-surface-variant flex items-center justify-between">
                <span>PSYCHOLOGICAL INTERPRETATION</span>
                {interpreting && <Loader2 className="w-3 h-3 text-secondary animate-spin" />}
              </span>

              {interpretation ? (
                <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-left space-y-2 text-xs leading-relaxed text-on-surface-variant">
                  <p className="whitespace-pre-wrap">{interpretation}</p>
                </div>
              ) : (
                <div className="glass-panel p-5 rounded-xl border border-dashed border-white/10 text-center space-y-3 bg-black/15">
                  <HelpCircle className="w-7 h-7 text-secondary/50 mx-auto animate-pulse" />
                  <p className="text-[11px] text-on-surface-variant max-w-xs mx-auto leading-relaxed">
                    Would you like to analyze this dream and look up its subconscious correlations and symbols?
                  </p>
                  <button
                    onClick={() => handleRequestInterpretation()}
                    disabled={interpreting}
                    className="px-4 py-2 bg-gradient-to-tr from-[#9efffc] to-[#ca9eff] text-[#0b0d1f] hover:brightness-110 rounded-full text-[10px] font-bold font-label-caps flex items-center justify-center gap-1.5 mx-auto transition-all transform hover:scale-[1.02] cursor-pointer"
                  >
                    {interpreting ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        INTERPRETING...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        SEEK INTERPRETATION
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Symbols Quick Dictionary Selector */}
            <div className="space-y-2 border-t border-white/5 pt-3">
              <span className="text-[10px] font-bold font-label-caps tracking-wider text-on-surface-variant block text-left">ASK ABOUT RECURRING SYMBOLS</span>
              <div className="flex flex-wrap gap-1.5 justify-start">
                {[
                  { name: "Water & Depth", detail: "Metaphor of deep emotions, the passive subconscious, or unresolved flow states of waking routine." },
                  { name: "Flight & Floating", detail: "Signifies lucid control, psychological empowerment, or the desire to rise above waking limitations." },
                  { name: "Falling Anomaly", detail: "Often mirrors minor stress, a threat of missing control parameters, or active high-pressure career tasks." },
                  { name: "Frozen Clocks", detail: "A prompt regarding waking time pressure, timeline transitions, or an active reminder to ground yourself." },
                  { name: "Shadow Figures", detail: "Shadow entities represent aspects of self or tensions projectively processed in REM stages." }
                ].map((s) => (
                  <button
                    key={s.name}
                    onClick={() => {
                      setSelectedPresetSymbol(s.name);
                      setInterpreterChat(prev => [
                        ...prev,
                        { sender: "user", text: `What is the psychological meaning of ${s.name}?` },
                        { sender: "somnia", text: s.detail }
                      ]);
                    }}
                    className="text-[10px] bg-white/5 border border-white/5 hover:border-secondary/30 text-on-surface hover:text-[#ca9eff] rounded-lg px-2.5 py-1 transition-all cursor-pointer text-left"
                  >
                    + {s.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Conversation chat with the interpreter */}
            <div className="space-y-2 pt-3 border-t border-white/5">
              <span className="text-[10px] font-bold font-label-caps tracking-wider text-on-surface-variant block uppercase text-left">Interactive Symbol Chat</span>
              
              <div className="min-h-[100px] max-h-[180px] overflow-y-auto bg-black/20 rounded-xl p-2.5 border border-white/5 space-y-2.5 text-xs text-left scrollbar-thin">
                {interpreterChat.length === 0 ? (
                  <p className="text-[10px] text-on-surface-variant/40 italic text-center py-4">No custom symbols queried yet. Type a question below or click a symbol to ask Somnia.</p>
                ) : (
                  interpreterChat.map((msg, mIdx) => (
                    <div key={mIdx} className={`space-y-1 ${msg.sender === "user" ? "text-right" : "text-left"}`}>
                      <span className="font-mono text-[9px] text-on-surface-variant/50 uppercase block">
                        {msg.sender === "user" ? "You" : "Somnia Guide"}
                      </span>
                      <div className={`p-2 rounded-lg inline-block text-xs ${
                        msg.sender === 'user' 
                          ? 'bg-secondary/15 border border-secondary/20 text-on-surface text-left' 
                          : 'bg-white/5 border border-white/5 text-on-surface-variant text-left'
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Chat action form input */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  if (customQuestion.trim()) {
                    handleRequestInterpretation(customQuestion);
                  }
                }}
                className="flex gap-1.5"
              >
                <input
                  type="text"
                  value={customQuestion}
                  onChange={(e) => setCustomQuestion(e.target.value)}
                  placeholder="Ask Somnia symbol..."
                  className="flex-grow bg-black/20 border border-white/10 rounded-full px-3 py-1.5 text-xs text-[#cac2e1] focus:border-[#ca9eff] outline-none placeholder:text-on-surface-variant/40"
                />
                <button
                  type="submit"
                  disabled={interpreting || !customQuestion.trim()}
                  className="p-1.5 rounded-full bg-secondary text-black hover:brightness-110 disabled:opacity-40 transition-all cursor-pointer flex items-center justify-center shrink-0 focus:outline-none"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          </div>
        </aside>
      )}
      </main>

      {/* Bottom Timeline Section (As per design Screen 4) */}
      <section className="h-[280px] bg-surface-container-high border-t border-white/10 flex flex-col relative z-20 shadow-[0_-10px_30px_rgba(0,0,0,0.5)] shrink-0">
        
        {/* Scrubber Tools bar bar */}
        <div className="h-10 bg-surface-variant flex items-center px-4 justify-between border-b border-white/5">
          <div className="flex items-center gap-3.5 text-on-surface-variant">
            <button className="hover:text-primary transition-colors cursor-pointer"><Scissors className="w-4 h-4" /></button>
            <button className="hover:text-primary transition-colors cursor-pointer"><Copy className="w-4 h-4" /></button>
            <button className="hover:text-primary transition-colors cursor-pointer"><Clipboard className="w-4 h-4" /></button>
            <div className="w-px h-4 bg-white/15" />
            <span className="text-[10px] font-mono select-none">ZOOM</span>
            <input
              type="range"
              min="1"
              max="10"
              defaultValue="5"
              className="w-16 h-1 bg-black/40 rounded-lg appearance-none cursor-pointer accent-primary focus:outline-none"
            />
          </div>
          <div className="text-[10px] font-label-caps text-secondary/7 tracking-widest font-bold uppercase select-none">
            Timeline : Sub-Conscious Tracks
          </div>
        </div>

        {/* Main draggable tracks grid split */}
        <div className="flex-grow flex overflow-hidden relative">
          
          {/* Left headers columns */}
          <div className="w-44 bg-[#181a2d] border-r border-white/10 flex flex-col shrink-0 relative z-10 shadow-[5px_0_10px_rgba(0,0,0,0.2)]">
            <div className="h-8 border-b border-white/5 flex items-center justify-end px-3">
              <span className="text-[9px] font-semibold text-on-surface-variant/50 uppercase font-mono tracking-wider">Tracks</span>
            </div>

            {/* Visuals track header */}
            <div className="h-14 border-b border-white/5 px-3 py-1 flex flex-col justify-center bg-black/10 hover:bg-black/20 transition-colors pointer-events-auto">
              <div className="flex items-center gap-1.5">
                <Tv className="w-3.5 h-3.5 text-secondary shrink-0" />
                <span className="font-title-md text-xs font-semibold text-on-surface">Visuals</span>
              </div>
              <div className="flex gap-2 mt-1 opacity-45">
                <Eye className="w-3.5 h-3.5 text-on-surface hover:text-white" />
                <Lock className="w-3.5 h-3.5 text-on-surface hover:text-white" />
              </div>
            </div>

            {/* Atmosphere track header */}
            <div className="h-14 border-b border-white/5 px-3 py-1 flex flex-col justify-center hover:bg-black/20 transition-colors pointer-events-auto">
              <div className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-tertiary shrink-0" />
                <span className="font-title-md text-xs font-semibold text-on-surface">Atmosphere</span>
              </div>
              <div className="flex gap-2 mt-1 opacity-45">
                <Eye className="w-3.5 h-3.5 text-on-surface hover:text-white" />
                <Lock className="w-3.5 h-3.5 text-on-surface hover:text-white" />
              </div>
            </div>

            {/* Lighting track header */}
            <div className="h-14 border-b border-white/5 px-3 py-1 flex flex-col justify-center hover:bg-black/20 transition-colors pointer-events-auto">
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-primary shrink-0" />
                <span className="font-title-md text-xs font-semibold text-on-surface">Lighting</span>
              </div>
              <div className="flex gap-2 mt-1 opacity-45">
                <Eye className="w-3.5 h-3.5 text-on-surface hover:text-white" />
                <Lock className="w-3.5 h-3.5 text-on-surface hover:text-white" />
              </div>
            </div>

            {/* Add Track CTA */}
            <button className="h-10 px-3 flex items-center text-on-surface-variant/40 hover:text-primary transition-colors border-none bg-transparent cursor-pointer text-left focus:outline-none focus:ring-0">
              <Plus className="w-3.5 h-3.5 mr-1.5" />
              <span className="text-[10px] font-bold uppercase tracking-wider font-label-caps">Add Track</span>
            </button>
          </div>

          {/* Right actual scroll clips area */}
          <div className="flex-1 overflow-x-auto overflow-y-hidden timeline-track-bg select-none relative bg-black/15">
            
            {/* Clickable Time ticks Ruler */}
            <div
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const progress = (e.clientX - rect.left) / rect.width;
                handleTimelineScrub(progress);
              }}
              className="h-8 border-b border-white/5 flex items-end relative sticky top-0 bg-surface-container-high/90 backdrop-blur-sm z-15 w-full cursor-ew-resize"
            >
              <div className="absolute inset-x-0 bottom-1 flex justify-between px-3 text-[9px] font-mono text-on-surface-variant/40 select-none">
                <span>00:00</span>
                <span>00:10</span>
                <span>00:20</span>
                <span>00:30</span>
                <span>00:40</span>
                <span>00:50</span>
              </div>
            </div>

            {/* Time vertical indicator scrubber line */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-tertiary z-20 pointer-events-none"
              style={{
                left: `${(currentTime / activeDream.duration) * 100}%`,
                boxShadow: "0 0 10px #00dbe9, 0 0 4px #00dbe9",
              }}
            >
              {/* Playhead circular knob */}
              <div className="absolute -top-1.5 -left-[6px] w-3 h-3 bg-[#00dbe9] rounded-full border border-white shadow-md animate-pulse" />
            </div>

            {/* Track rows background grid */}
            <div className="w-full relative flex flex-col">
              
              {/* Row 1: Visuals Clips */}
              <div className="h-14 border-b border-white/5 relative flex items-center px-1.5">
                {activeDream.tracks.visuals.map((clip) => {
                  const isActive = currentTime >= clip.start && currentTime <= clip.start + clip.duration;
                  const left = (clip.start / activeDream.duration) * 100;
                  const width = (clip.duration / activeDream.duration) * 100;
                  
                  return (
                    <div
                      key={clip.id}
                      className={`absolute h-[76%] rounded flex items-center px-2.5 overflow-hidden transition-all text-xs border ${
                        isActive
                          ? "bg-secondary-container/20 border-secondary shadow-[0_0_12px_rgba(236,178,255,0.15)] text-white font-semibold ring-1 ring-secondary/30"
                          : "bg-[#27283c]/50 border-white/10 text-on-surface-variant/80"
                      }`}
                      style={{ left: `${left}%`, width: `${width}%` }}
                    >
                      <Tv className="w-3 h-3 mr-1.5 shrink-0 select-none" />
                      <span className="truncate">{clip.name}</span>
                    </div>
                  );
                })}
              </div>

              {/* Row 2: Atmosphere Clips */}
              <div className="h-14 border-b border-white/5 relative flex items-center px-1.5">
                {activeDream.tracks.atmosphere.map((clip) => {
                  const isActive = currentTime >= clip.start && currentTime <= clip.start + clip.duration;
                  const left = (clip.start / activeDream.duration) * 100;
                  const width = (clip.duration / activeDream.duration) * 100;
                  
                  return (
                    <div
                      key={clip.id}
                      className={`absolute h-[68%] rounded-full flex items-center px-3.5 overflow-hidden transition-all text-[11px] border border-dashed ${
                        isActive
                          ? "bg-tertiary-container/30 border-tertiary text-tertiary shadow-[0_0_10px_rgba(0,219,233,0.1)] font-semibold"
                          : "bg-black/20 border-white/5 text-on-surface-variant/60"
                      }`}
                      style={{ left: `${left}%`, width: `${width}%` }}
                    >
                      <div className={`w-1.5 h-1.5 rounded-full mr-2 ${isActive ? "bg-tertiary animate-ping" : "bg-white/10"}`} />
                      <span className="truncate font-mono uppercase tracking-wider">{clip.name}</span>
                    </div>
                  );
                })}
              </div>

              {/* Row 3: Lighting Clips */}
              <div className="h-14 border-b border-white/5 relative flex items-center px-1.5">
                {activeDream.tracks.lighting.map((clip) => {
                  const isActive = currentTime >= clip.start && currentTime <= clip.start + clip.duration;
                  const left = (clip.start / activeDream.duration) * 100;
                  const width = (clip.duration / activeDream.duration) * 100;
                  
                  return (
                    <div
                      key={clip.id}
                      className={`absolute h-[54%] rounded flex items-center justify-center text-[10px] font-semibold transition-all border ${
                        isActive
                          ? "bg-[#cac2e1]/15 border-primary text-[#cac2e1]"
                          : "bg-black/10 border-white/5 text-on-surface-variant/40"
                      }`}
                      style={{ left: `${left}%`, width: `${width}%` }}
                    >
                      <span className="truncate">{clip.name}</span>
                    </div>
                  );
                })}
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* Studio Walkthrough Interactive Overlay */}
      <AnimatePresence>
        {showStudioGuide && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#121424] border border-[#ca9eff]/30 shadow-2xl p-6 rounded-2xl max-w-md w-full text-left space-y-4 relative"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#ca9eff] font-extrabold">
                  Interactive Tour — Step {currentGuideStep + 1} of {guideSteps.length}
                </span>
                <button
                  onClick={() => setShowStudioGuide(false)}
                  className="text-on-surface-variant hover:text-white transition-all text-sm font-bold bg-white/5 rounded-full w-6 h-6 flex items-center justify-center cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-black tracking-wider text-white font-label-caps uppercase">
                  {guideSteps[currentGuideStep].title}
                </h4>
                <p className="text-xs text-[#cac5e4] leading-relaxed">
                  {guideSteps[currentGuideStep].text}
                </p>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  onClick={() => setShowStudioGuide(false)}
                  className="text-xs text-on-surface-variant hover:text-white transition-colors cursor-pointer font-semibold"
                >
                  Skip Tour
                </button>

                <div className="flex items-center gap-2">
                  {currentGuideStep > 0 && (
                    <button
                      onClick={() => setCurrentGuideStep(prev => prev - 1)}
                      className="px-3 py-1.5 bg-white/5 border border-white/5 text-on-surface hover:text-white text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Back
                    </button>
                  )}
                  {currentGuideStep < guideSteps.length - 1 ? (
                    <button
                      onClick={() => setCurrentGuideStep(prev => prev + 1)}
                      className="px-4 py-1.5 bg-gradient-to-tr from-[#9efffc] to-[#ca9eff] text-[#05060f] font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Next step
                    </button>
                  ) : (
                    <button
                      onClick={() => setShowStudioGuide(false)}
                      className="px-4 py-1.5 bg-secondary text-white font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Got it, thanks!
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
